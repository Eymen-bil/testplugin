package com.educraft.lobby;

import com.educraft.EduCraftPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class LobbyManager {

    private final EduCraftPlugin plugin;

    public LobbyManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void sendToLobby(Player player) {
        Location lobbyLoc = plugin.getConfigManager().getLobbyLocation();
        if (lobbyLoc == null) {
            plugin.getLogger().severe("Lobby location is not configured properly!");
            return;
        }

        Bukkit.getScheduler().runTask(plugin, () -> {
            player.teleport(lobbyLoc);
            player.sendMessage(Component.text("EduCraft Lobby'sine hoş geldiniz!", NamedTextColor.GREEN));
        });
    }
}

