package com.educraft.puzzle;

import com.educraft.EduCraftPlugin;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class PuzzleManager {

    private final EduCraftPlugin plugin;
    private final Set<String> whitelistedPuzzles;

    public PuzzleManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.whitelistedPuzzles = ConcurrentHashMap.newKeySet();
        whitelistedPuzzles.add("gate_01");
        whitelistedPuzzles.add("button_sequence_1");
    }

    public boolean executePuzzle(String puzzleId) {
        if (!whitelistedPuzzles.contains(puzzleId)) {
            plugin.getLogger().warning("Unsanitized or unknown puzzle execution blocked: " + puzzleId);
            return false;
        }
        return true;
    }
}

