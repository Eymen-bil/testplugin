package com.educraft.listener;

import com.educraft.EduCraftPlugin;
import com.educraft.quiz.Question;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;

import java.util.List;

public class PlayerInteractListener implements Listener {

    private final EduCraftPlugin plugin;

    public PlayerInteractListener(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        if (event.getRightClicked() instanceof Villager villager) {
            Player player = event.getPlayer();
            event.setCancelled(true);

            Question sampleQuestion = new Question(
                "q123",
                "MULTIPLE_CHOICE",
                "2x + 4 = 16 ise x kaçtır?",
                List.of("4", "6", "8", "10")
            );

            plugin.getQuizManager().startQuestion(player, sampleQuestion);
        }
    }
}

