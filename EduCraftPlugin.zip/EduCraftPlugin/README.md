# EduCraftPlugin

EduCraftPlugin, Paper 1.21.8 ve Java 21 platformları için özel olarak geliştirilmiş bir eğitim simülasyonu Minecraft eklentisidir.

## Özellikler
- **Sıfır Dünya Üretimi**: Mevcut haritalar üzerindeki önceden hazırlanmış Arenaları (Region) dinamik yönetir.
- **Güvenli Mimari**: Veritabanı bağlantısı doğrudan yapılmaz; EduCraft API üzerinden asenkron HTTPS/HMAC SHA-256 ile iletişim kurulur.
- **Sınıf (Class) ve Solo Modları**: Öğretmen merkezli sınıf oturumları veya bireysel öğrenci deneyimleri.
- **Dinamik Temizlik**: Oturum bittiğinde Arena otomatik olarak sıfırlanır, entity ve NPC'ler temizlenir.

## Kurulum ve Derleme

### Gereksinimler
- Java 21 SDK
- Maven 3.8+
- Paper 1.21.8 Sunucusu

### Derleme
