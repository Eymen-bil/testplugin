package com.educraft.quest;

import java.util.List;

public class Quest {
    private final String questId;
    private final String title;
    private final List<QuestStep> steps;
    private int currentStepIndex;

    public Quest(String questId, String title, List<QuestStep> steps) {
        this.questId = questId;
        this.title = title;
        this.steps = steps;
        this.currentStepIndex = 0;
    }

    public String getQuestId() { return questId; }
    public String getTitle() { return title; }
    public List<QuestStep> getSteps() { return steps; }
    public int getCurrentStepIndex() { return currentStepIndex; }

    public QuestStep getCurrentStep() {
        if (currentStepIndex >= 0 && currentStepIndex < steps.size()) {
            return steps.get(currentStepIndex);
        }
        return null;
    }

    public boolean advance() {
        if (currentStepIndex < steps.size() - 1) {
            currentStepIndex++;
            return true;
        }
        return false;
    }
}

