package com.educraft.command;

import com.educraft.EduCraftPlugin;
import com.educraft.session.GameSession;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class EduCraftCommand implements CommandExecutor {

    private final EduCraftPlugin plugin;

    public EduCraftCommand(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Bu komut sadece oyuncular içindir.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(Component.text("=== EduCraft System ===", NamedTextColor.GOLD));
            player.sendMessage(Component.text("/educraft status - Durum bilgisini gösterir", NamedTextColor.YELLOW));
            player.sendMessage(Component.text("/educraft lobby - Lobby'ye ışınlar", NamedTextColor.YELLOW));
            return true;
        }

        if (args[0].equalsIgnoreCase("lobby")) {
            plugin.getLobbyManager().sendToLobby(player);
            return true;
        }

        if (args[0].equalsIgnoreCase("status")) {
            Optional<GameSession> sessionOpt = plugin.getSessionManager().getSessionForPlayer(player.getUniqueId());
            if (sessionOpt.isPresent()) {
                GameSession session = sessionOpt.get();
                player.sendMessage(Component.text("Aktif Oturum: " + session.getSessionId() + " [" + session.getStatus() + "]", NamedTextColor.GREEN));
            } else {
                player.sendMessage(Component.text("Aktif bir oturumda değilsiniz.", NamedTextColor.GRAY));
            }
            return true;
        }

        return false;
    }
}

