package com.educraft.listener;

import com.educraft.EduCraftPlugin;
import com.educraft.session.GameSession;
import com.educraft.session.SessionStatus;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

import java.util.Optional;

public class DamageListener implements Listener {

    private final EduCraftPlugin plugin;

    public DamageListener(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            Optional<GameSession> sessionOpt = plugin.getSessionManager().getSessionForPlayer(player.getUniqueId());
            if (sessionOpt.isPresent()) {
                GameSession session = sessionOpt.get();
                if (session.getStatus() == SessionStatus.PAUSED) {
                    event.setCancelled(true);
                }
            }
        }
    }
}

