package com.educraft.security;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.UUID;
import java.util.regex.Pattern;

public class SessionSecurity {

    private static final Pattern SAFE_COMMAND_PATTERN = Pattern.compile("^[a-zA-Z0-9_\\-\\s.]+");

    public static String generateNonce() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static String computeHmacSha256(String data, String secret) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
            mac.init(secretKey);
            byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException("Error computing HMAC signature", e);
        }
    }

    public static boolean validateTimestamp(long timestampMs, long maxAgeMs) {
        long current = System.currentTimeMillis();
        return Math.abs(current - timestampMs) <= maxAgeMs;
    }

    public static boolean sanitizeCommand(String rawCommand) {
        if (rawCommand == null || rawCommand.isBlank()) return false;
        String lower = rawCommand.toLowerCase().trim();
        
        if (lower.startsWith("/op") || lower.startsWith("op ") ||
            lower.startsWith("/execute") || lower.startsWith("execute ") ||
            lower.startsWith("/stop") || lower.startsWith("stop") ||
            lower.startsWith("/ban") || lower.startsWith("ban ") ||
            lower.startsWith("/permission") || lower.startsWith("permission ") ||
            lower.startsWith("/deop") || lower.startsWith("deop ")) {
            return false;
        }

        return SAFE_COMMAND_PATTERN.matcher(rawCommand).matches();
    }
}

