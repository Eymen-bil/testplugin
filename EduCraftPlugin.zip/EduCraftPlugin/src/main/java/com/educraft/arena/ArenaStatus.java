package com.educraft.arena;

public enum ArenaStatus {
    AVAILABLE,
    IN_USE,
    CLEANING,
    DISABLED
}

