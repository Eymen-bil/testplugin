package com.educraft.analytics;

import com.educraft.EduCraftPlugin;
import com.educraft.api.ApiResponse;
import com.fasterxml.jackson.core.type.TypeReference;

import java.util.HashMap;
import java.util.Map;

public class AnalyticsManager {

    private final EduCraftPlugin plugin;

    public AnalyticsManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void trackEvent(String eventName, String sessionId, String playerUuid, Map<String, Object> metadata) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("event", eventName);
        payload.put("sessionId", sessionId);
        payload.put("playerUuid", playerUuid);
        payload.put("timestamp", System.currentTimeMillis());
        payload.put("metadata", metadata != null ? metadata : Map.of());

        plugin.getApiClient().postAsync("/minecraft/analytics", payload, new TypeReference<ApiResponse<Void>>() {});
    }
}

