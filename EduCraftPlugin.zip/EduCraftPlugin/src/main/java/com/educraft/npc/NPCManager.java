package com.educraft.npc;

import com.educraft.EduCraftPlugin;
import com.educraft.arena.Arena;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class NPCManager {

    private final EduCraftPlugin plugin;
    private final Map<String, EduNPC> activeNpcs;

    public NPCManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.activeNpcs = new ConcurrentHashMap<>();
    }

    public void spawnNPC(String sessionId, EduNPC npc, Arena arena) {
        Location spawnLoc = arena.getNpcLocations().get(npc.getLocationKey());
        if (spawnLoc == null) {
            spawnLoc = arena.getSpawnPoint();
        }

        Location finalLoc = spawnLoc;
        Bukkit.getScheduler().runTask(plugin, () -> {
            Villager villager = (Villager) finalLoc.getWorld().spawnEntity(finalLoc, EntityType.VILLAGER);
            villager.customName(Component.text(npc.getName(), NamedTextColor.GOLD));
            villager.setCustomNameVisible(true);
            villager.setAI(false);
            villager.setInvulnerable(true);
            npc.setEntity(villager);
            activeNpcs.put(sessionId + ":" + npc.getId(), npc);
        });
    }

    public void removeNPCsForSession(String sessionId) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            Iterator<Map.Entry<String, EduNPC>> iterator = activeNpcs.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, EduNPC> entry = iterator.next();
                if (entry.getKey().startsWith(sessionId + ":")) {
                    if (entry.getValue().getEntity() != null && !entry.getValue().getEntity().isDead()) {
                        entry.getValue().getEntity().remove();
                    }
                    iterator.remove();
                }
            }
        });
    }
}

