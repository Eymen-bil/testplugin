package com.educraft.command;

import com.educraft.EduCraftPlugin;
import com.educraft.arena.Arena;
import com.educraft.session.GameSession;
import com.educraft.session.SessionMode;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public class EduCraftAdminCommand implements CommandExecutor {

    private final EduCraftPlugin plugin;

    public EduCraftAdminCommand(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("educraft.admin")) {
            sender.sendMessage(Component.text("Yetkiniz yok.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(Component.text("=== EduCraft Admin ===", NamedTextColor.DARK_RED));
            sender.sendMessage(Component.text("/educraftadmin reload", NamedTextColor.RED));
            sender.sendMessage(Component.text("/educraftadmin testsolo", NamedTextColor.RED));
            sender.sendMessage(Component.text("/educraftadmin arenas", NamedTextColor.RED));
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            plugin.getConfigManager().loadConfig();
            sender.sendMessage(Component.text("Konfigürasyon yeniden yüklendi.", NamedTextColor.GREEN));
            return true;
        }

        if (args[0].equalsIgnoreCase("arenas")) {
            sender.sendMessage(Component.text("--- Arenalar ---", NamedTextColor.GOLD));
            for (Arena arena : plugin.getArenaManager().getArenas().values()) {
                sender.sendMessage(Component.text(arena.getArenaId() + ": " + arena.getStatus(), NamedTextColor.YELLOW));
            }
            return true;
        }

        if (args[0].equalsIgnoreCase("testsolo") && sender instanceof Player player) {
            String sessionId = "test-" + UUID.randomUUID().toString().substring(0, 8);
            GameSession session = new GameSession(sessionId, SessionMode.SOLO, null, "lost-seal");
            session.addPlayer(new com.educraft.session.SessionPlayer(player.getUniqueId(), player.getName()));
            
            plugin.getSessionManager().registerSession(session);
            plugin.getSessionManager().startSession(session);
            sender.sendMessage(Component.text("Test Solo Session Başlatıldı: " + sessionId, NamedTextColor.GREEN));
            return true;
        }

        return false;
    }
}

