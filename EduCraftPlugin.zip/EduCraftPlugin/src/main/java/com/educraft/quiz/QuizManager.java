package com.educraft.quiz;

import com.educraft.EduCraftPlugin;
import com.educraft.api.ApiResponse;
import com.educraft.session.GameSession;
import com.educraft.session.SessionStatus;
import com.fasterxml.jackson.core.type.TypeReference;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class QuizManager {

    private final EduCraftPlugin plugin;
    private final Map<UUID, Question> activeQuestions;

    public QuizManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.activeQuestions = new ConcurrentHashMap<>();
    }

    public void startQuestion(Player player, Question question) {
        activeQuestions.put(player.getUniqueId(), question);

        Bukkit.getScheduler().runTask(plugin, () -> {
            Inventory gui = Bukkit.createInventory(null, 27, Component.text("Soru: " + question.questionId(), NamedTextColor.BLUE, TextDecoration.BOLD));

            ItemStack paper = new ItemStack(Material.PAPER);
            ItemMeta paperMeta = paper.getItemMeta();
            paperMeta.displayName(Component.text(question.question(), NamedTextColor.YELLOW));
            paper.setItemMeta(paperMeta);
            gui.setItem(4, paper);

            List<String> options = question.options();
            int[] slots = {10, 12, 14, 16};
            for (int i = 0; i < Math.min(options.size(), slots.length); i++) {
                ItemStack optionItem = new ItemStack(Material.BOOK);
                ItemMeta meta = optionItem.getItemMeta();
                meta.displayName(Component.text(options.get(i), NamedTextColor.GREEN));
                optionItem.setItemMeta(meta);
                gui.setItem(slots[i], optionItem);
            }

            player.openInventory(gui);
        });
    }

    public void submitAnswer(Player player, String selectedAnswer) {
        Question q = activeQuestions.get(player.getUniqueId());
        if (q == null) return;

        Optional<GameSession> sessionOpt = plugin.getSessionManager().getSessionForPlayer(player.getUniqueId());
        if (sessionOpt.isEmpty()) return;

        GameSession session = sessionOpt.get();
        if (session.getStatus() == SessionStatus.PAUSED) {
            player.sendMessage(Component.text("Oyun duraklatıldığı için cevap veremezsiniz!", NamedTextColor.RED));
            return;
        }

        Map<String, String> payload = Map.of(
            "sessionId", session.getSessionId(),
            "minecraftUuid", player.getUniqueId().toString(),
            "questionId", q.questionId(),
            "answer", selectedAnswer
        );

        plugin.getAnalyticsManager().trackEvent("QUESTION_ANSWERED", session.getSessionId(), player.getUniqueId().toString(), Map.of("questionId", q.questionId()));

        plugin.getApiClient().postAsync("/minecraft/answer", payload, new TypeReference<ApiResponse<AnswerResult>>() {})
            .thenAccept(response -> Bukkit.getScheduler().runTask(plugin, () -> {
                if (response != null && response.success() && response.data() != null) {
                    AnswerResult result = response.data();
                    showResult(player, result);
                    if (result.correct()) {
                        plugin.getAnalyticsManager().trackEvent("QUESTION_CORRECT", session.getSessionId(), player.getUniqueId().toString(), Map.of("xp", String.valueOf(result.xp())));
                    } else {
                        plugin.getAnalyticsManager().trackEvent("QUESTION_WRONG", session.getSessionId(), player.getUniqueId().toString(), Map.of());
                    }
                } else {
                    player.sendMessage(Component.text("Cevap işlenirken bir hata oluştu.", NamedTextColor.RED));
                }
                activeQuestions.remove(player.getUniqueId());
                player.closeInventory();
            }));
    }

    public void showResult(Player player, AnswerResult result) {
        if (result.correct()) {
            player.sendMessage(Component.text("✔ " + result.feedback() + " (+" + result.xp() + " XP)", NamedTextColor.GREEN));
            player.giveExp(result.xp());
        } else {
            player.sendMessage(Component.text("✘ " + result.feedback(), NamedTextColor.RED));
        }
    }

    public boolean hasActiveQuestion(UUID uuid) {
        return activeQuestions.containsKey(uuid);
    }
}

