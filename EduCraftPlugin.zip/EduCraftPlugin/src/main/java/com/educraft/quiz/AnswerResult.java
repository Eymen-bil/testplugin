package com.educraft.quiz;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record AnswerResult(
    boolean correct,
    int score,
    int xp,
    String feedback,
    double questProgress
) {}

