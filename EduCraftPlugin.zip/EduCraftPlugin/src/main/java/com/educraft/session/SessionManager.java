package com.educraft.session;

import com.educraft.EduCraftPlugin;
import com.educraft.api.ApiResponse;
import com.educraft.arena.Arena;
import com.educraft.npc.EduNPC;
import com.fasterxml.jackson.core.type.TypeReference;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SessionManager {

    private final EduCraftPlugin plugin;
    private final Map<String, GameSession> activeSessions;
    private final Map<UUID, String> playerToSession;

    public SessionManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.activeSessions = new ConcurrentHashMap<>();
        this.playerToSession = new ConcurrentHashMap<>();
    }

    public void registerSession(GameSession session) {
        activeSessions.put(session.getSessionId(), session);
    }

    public void unregisterSession(String sessionId) {
        GameSession session = activeSessions.remove(sessionId);
        if (session != null) {
            playerToSession.entrySet().removeIf(entry -> entry.getValue().equals(sessionId));
        }
    }

    public Optional<GameSession> getSession(String sessionId) {
        return Optional.ofNullable(activeSessions.get(sessionId));
    }

    public Optional<GameSession> getSessionForPlayer(UUID uuid) {
        String sessionId = playerToSession.get(uuid);
        return sessionId != null ? getSession(sessionId) : Optional.empty();
    }

    public void startSession(GameSession session) {
        Optional<Arena> arenaOpt = plugin.getArenaManager().allocateArena();
        if (arenaOpt.isEmpty()) {
            plugin.getLogger().warning("No available arena for session: " + session.getSessionId());
            return;
        }

        Arena arena = arenaOpt.get();
        session.setArenaId(arena.getArenaId());
        session.setStatus(SessionStatus.STARTING);

        for (SessionPlayer sp : session.getPlayers().values()) {
            playerToSession.put(sp.getUuid(), session.getSessionId());
            Player p = Bukkit.getPlayer(sp.getUuid());
            if (p != null) {
                plugin.getTeleportManager().teleportToArena(p, arena, session);
            }
        }

        EduNPC testNpc = new EduNPC("elder_arin", "Elder Arin", "ARENA_NPC_1", "lost-seal");
        plugin.getNpcManager().spawnNPC(session.getSessionId(), testNpc, arena);

        session.setStatus(SessionStatus.RUNNING);
        plugin.getAnalyticsManager().trackEvent("GAME_STARTED", session.getSessionId(), "SYSTEM", Map.of("mode", session.getMode().name()));
    }

    public void pauseSession(GameSession session) {
        session.setStatus(SessionStatus.PAUSED);
    }

    public void resumeSession(GameSession session) {
        session.setStatus(SessionStatus.RUNNING);
    }

    public void completeSession(GameSession session) {
        plugin.getAnalyticsManager().trackEvent("GAME_COMPLETED", session.getSessionId(), "SYSTEM", Map.of());
        plugin.getCleanupManager().cleanupSession(session);
    }

    public void syncSessionsFromBackend() {
        plugin.getApiClient().getAsync("/minecraft/active-sessions", new TypeReference<ApiResponse<List<Map<String, Object>>>>() {})
            .thenAccept(response -> {
                if (response != null && response.success() && response.data() != null) {
                    plugin.getLogger().info("Synced active sessions from backend.");
                }
            });
    }

    public Map<String, GameSession> getActiveSessions() {
        return activeSessions;
    }
}

