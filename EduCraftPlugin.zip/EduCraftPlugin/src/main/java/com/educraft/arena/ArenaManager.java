package com.educraft.arena;

import com.educraft.EduCraftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ArenaManager {

    private final EduCraftPlugin plugin;
    private final Map<String, Arena> arenas;
    private final ArenaAllocator allocator;
    private final ArenaResetter resetter;

    public ArenaManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.arenas = new ConcurrentHashMap<>();
        this.allocator = new ArenaAllocator(arenas);
        this.resetter = new ArenaResetter(plugin);
        discoverArenas();
    }

    public void discoverArenas() {
        World world = Bukkit.getWorld("world");
        if (world == null && !Bukkit.getWorlds().isEmpty()) {
            world = Bukkit.getWorlds().get(0);
        }
        if (world == null) return;

        for (int i = 1; i <= 5; i++) {
            String arenaId = "EDU_ARENA_" + i;
            Location min = new Location(world, i * 200, 60, i * 200);
            Location max = new Location(world, (i * 200) + 100, 120, (i * 200) + 100);
            Location spawn = new Location(world, (i * 200) + 50, 65, (i * 200) + 50);
            Location bossLoc = new Location(world, (i * 200) + 70, 65, (i * 200) + 70);

            Map<String, Location> npcLocs = new HashMap<>();
            npcLocs.put("ARENA_NPC_1", new Location(world, (i * 200) + 40, 65, (i * 200) + 40));

            Arena arena = new Arena(arenaId, arenaId, world, min, max, spawn, npcLocs, bossLoc);
            arenas.put(arenaId, arena);
        }
    }

    public Optional<Arena> allocateArena() {
        return allocator.allocateNextAvailable();
    }

    public void releaseAndResetArena(String arenaId) {
        Arena arena = arenas.get(arenaId);
        if (arena == null) return;

        allocator.releaseArena(arenaId);
        resetter.resetArena(arena).thenAccept(success -> {
            if (success) {
                arena.setStatus(ArenaStatus.AVAILABLE);
            } else {
                arena.setStatus(ArenaStatus.DISABLED);
            }
        });
    }

    public Map<String, Arena> getArenas() { return arenas; }
    public Arena getArena(String arenaId) { return arenas.get(arenaId); }
    
    public Optional<Arena> getArenaForLocation(Location loc) {
        return arenas.values().stream().filter(a -> a.contains(loc)).findFirst();
    }
}

