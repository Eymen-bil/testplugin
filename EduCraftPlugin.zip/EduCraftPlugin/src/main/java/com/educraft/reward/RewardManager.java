package com.educraft.reward;

import com.educraft.EduCraftPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;

public class RewardManager {

    private final EduCraftPlugin plugin;

    public RewardManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void rewardPlayer(Player player, int xpAmount, String achievement) {
        player.giveExp(xpAmount);
        player.sendMessage(Component.text("Tebrikler! " + xpAmount + " XP ve Başarım Kazandınız: " + achievement, NamedTextColor.GOLD));
    }
}

