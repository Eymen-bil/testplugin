package com.educraft.listener;

import com.educraft.EduCraftPlugin;
import com.educraft.arena.Arena;
import com.educraft.session.GameSession;
import com.educraft.session.SessionStatus;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.Optional;

public class MovementListener implements Listener {

    private final EduCraftPlugin plugin;

    public MovementListener(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        Optional<GameSession> sessionOpt = plugin.getSessionManager().getSessionForPlayer(player.getUniqueId());

        if (sessionOpt.isPresent()) {
            GameSession session = sessionOpt.get();
            if (session.getStatus() == SessionStatus.PAUSED) {
                if (event.hasChangedBlock()) {
                    event.setCancelled(true);
                }
                return;
            }

            Arena arena = plugin.getArenaManager().getArena(session.getArenaId());
            if (arena != null) {
                Location to = event.getTo();
                if (!arena.contains(to)) {
                    event.setCancelled(true);
                    player.teleport(arena.getSpawnPoint());
                }
            }
        }
    }
}

