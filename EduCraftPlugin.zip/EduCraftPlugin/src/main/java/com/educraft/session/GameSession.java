package com.educraft.session;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameSession {
    private final String sessionId;
    private final SessionMode mode;
    private SessionStatus status;
    private String arenaId;
    private final Map<UUID, SessionPlayer> players;
    private final String activeQuestId;
    private long startTime;

    public GameSession(String sessionId, SessionMode mode, String arenaId, String activeQuestId) {
        this.sessionId = sessionId;
        this.mode = mode;
        this.status = SessionStatus.WAITING;
        this.arenaId = arenaId;
        this.players = new ConcurrentHashMap<>();
        this.activeQuestId = activeQuestId;
        this.startTime = System.currentTimeMillis();
    }

    public String getSessionId() { return sessionId; }
    public SessionMode getMode() { return mode; }
    public SessionStatus getStatus() { return status; }
    public void setStatus(SessionStatus status) { this.status = status; }
    public String getArenaId() { return arenaId; }
    public void setArenaId(String arenaId) { this.arenaId = arenaId; }
    public Map<UUID, SessionPlayer> getPlayers() { return players; }
    public String getActiveQuestId() { return activeQuestId; }
    public long getStartTime() { return startTime; }

    public void addPlayer(SessionPlayer player) {
        players.put(player.getUuid(), player);
    }

    public void removePlayer(UUID uuid) {
        players.remove(uuid);
    }

    public boolean hasPlayer(UUID uuid) {
        return players.containsKey(uuid);
    }
}

