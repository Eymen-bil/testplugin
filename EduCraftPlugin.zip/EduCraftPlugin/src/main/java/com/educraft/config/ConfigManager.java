package com.educraft.config;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import com.educraft.EduCraftPlugin;

public class ConfigManager {

    private final EduCraftPlugin plugin;
    private String apiBaseUrl;
    private String apiKey;
    private String apiSecret;
    private long apiTimeoutMs;
    private Location lobbyLocation;
    private long syncIntervalMs;
    private long resetTimeoutMs;
    private long maxRequestAgeMs;
    private boolean debug;

    public ConfigManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadConfig() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration config = plugin.getConfig();

        this.apiBaseUrl = config.getString("api.base-url", "https://example.com/api");
        this.apiKey = config.getString("api.api-key", "");
        this.apiSecret = config.getString("api.api-secret", "");
        this.apiTimeoutMs = config.getLong("api.timeout-ms", 5000);

        String worldName = config.getString("lobby.world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            world = Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
        }
        double x = config.getDouble("lobby.x", 0.5);
        double y = config.getDouble("lobby.y", 100.0);
        double z = config.getDouble("lobby.z", 0.5);
        float yaw = (float) config.getDouble("lobby.yaw", 0.0);
        float pitch = (float) config.getDouble("lobby.pitch", 0.0);

        if (world != null) {
            this.lobbyLocation = new Location(world, x, y, z, yaw, pitch);
        }

        this.syncIntervalMs = config.getLong("session.sync-interval-ms", 3000);
        this.resetTimeoutMs = config.getLong("arena.reset-timeout-ms", 30000);
        this.maxRequestAgeMs = config.getLong("security.max-request-age-ms", 10000);
        this.debug = config.getBoolean("debug", false);
    }

    public String getApiBaseUrl() { return apiBaseUrl; }
    public String getApiKey() { return apiKey; }
    public String getApiSecret() { return apiSecret; }
    public long getApiTimeoutMs() { return apiTimeoutMs; }
    public Location getLobbyLocation() { return lobbyLocation; }
    public long getSyncIntervalMs() { return syncIntervalMs; }
    public long getResetTimeoutMs() { return resetTimeoutMs; }
    public long getMaxRequestAgeMs() { return maxRequestAgeMs; }
    public boolean isDebug() { return debug; }
}

