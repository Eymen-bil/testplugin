package com.educraft.boss;

import com.educraft.EduCraftPlugin;
import com.educraft.arena.Arena;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.WitherSkeleton;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BossManager {

    private final EduCraftPlugin plugin;
    private final Map<String, WitherSkeleton> activeBosses;

    public BossManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.activeBosses = new ConcurrentHashMap<>();
    }

    public void spawnBoss(String sessionId, String bossName, Arena arena) {
        Location bossLoc = arena.getBossLocation();

        Bukkit.getScheduler().runTask(plugin, () -> {
            WitherSkeleton boss = (WitherSkeleton) bossLoc.getWorld().spawnEntity(bossLoc, EntityType.WITHER_SKELETON);
            boss.customName(Component.text(bossName, NamedTextColor.RED));
            boss.setCustomNameVisible(true);
            activeBosses.put(sessionId, boss);
        });
    }

    public void removeBossForSession(String sessionId) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            WitherSkeleton boss = activeBosses.remove(sessionId);
            if (boss != null && !boss.isDead()) {
                boss.remove();
            }
        });
    }
}

