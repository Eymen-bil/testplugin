package com.educraft.quest;

public record QuestStep(
    int stepNumber,
    String type,
    String targetId,
    String description
) {}

