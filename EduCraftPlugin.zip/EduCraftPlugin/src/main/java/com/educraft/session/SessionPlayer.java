package com.educraft.session;

import java.util.UUID;

public class SessionPlayer {
    private final UUID uuid;
    private final String username;
    private int score;
    private int xpGained;

    public SessionPlayer(UUID uuid, String username) {
        this.uuid = uuid;
        this.username = username;
        this.score = 0;
        this.xpGained = 0;
    }

    public UUID getUuid() { return uuid; }
    public String getUsername() { return username; }
    public int getScore() { return score; }
    public void addScore(int delta) { this.score += delta; }
    public int getXpGained() { return xpGained; }
    public void addXp(int delta) { this.xpGained += delta; }
}

