package com.educraft.listener;

import com.educraft.EduCraftPlugin;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class InventoryListener implements Listener {

    private final EduCraftPlugin plugin;

    public InventoryListener(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            if (plugin.getQuizManager().hasActiveQuestion(player.getUniqueId())) {
                event.setCancelled(true);
                ItemStack currentItem = event.getCurrentItem();
                if (currentItem != null && currentItem.getType() == Material.BOOK && currentItem.hasItemMeta()) {
                    String selectedAnswer = PlainTextComponentSerializer.plainText().serialize(currentItem.getItemMeta().displayName());
                    plugin.getQuizManager().submitAnswer(player, selectedAnswer);
                }
            }
        }
    }
}

