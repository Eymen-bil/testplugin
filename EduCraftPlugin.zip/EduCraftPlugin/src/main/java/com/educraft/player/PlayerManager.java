package com.educraft.player;

import com.educraft.EduCraftPlugin;
import com.fasterxml.jackson.core.type.TypeReference;
import com.educraft.api.ApiResponse;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public class PlayerManager {

    private final EduCraftPlugin plugin;
    private final Map<UUID, Boolean> authenticatedPlayers;

    public PlayerManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.authenticatedPlayers = new ConcurrentHashMap<>();
    }

    public CompletableFuture<Boolean> authenticatePlayer(Player player) {
        Map<String, String> body = Map.of(
            "minecraftUuid", player.getUniqueId().toString(),
            "username", player.getName()
        );

        return plugin.getApiClient().postAsync("/minecraft/auth", body, new TypeReference<ApiResponse<Map<String, Object>>>() {})
            .thenApply(response -> {
                boolean authenticated = response != null && response.success();
                authenticatedPlayers.put(player.getUniqueId(), authenticated);
                return authenticated;
            });
    }

    public boolean isAuthenticated(UUID uuid) {
        return authenticatedPlayers.getOrDefault(uuid, false);
    }

    public void removePlayer(UUID uuid) {
        authenticatedPlayers.remove(uuid);
    }
}

