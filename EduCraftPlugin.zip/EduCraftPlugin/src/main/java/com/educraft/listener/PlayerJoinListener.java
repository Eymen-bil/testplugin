package com.educraft.listener;

import com.educraft.EduCraftPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {

    private final EduCraftPlugin plugin;

    public PlayerJoinListener(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getPlayerManager().authenticatePlayer(player).thenAccept(authenticated -> {
            if (!authenticated) {
                plugin.getLobbyManager().sendToLobby(player);
            }
        });
    }
}

