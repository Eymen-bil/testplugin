package com.educraft.api;

public record ApiAuth(
    String apiKey,
    String signature,
    long timestamp,
    String nonce
) {}

