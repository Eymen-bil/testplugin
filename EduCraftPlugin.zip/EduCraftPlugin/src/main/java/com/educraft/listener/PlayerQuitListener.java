package com.educraft.listener;

import com.educraft.EduCraftPlugin;
import com.educraft.session.GameSession;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Optional;

public class PlayerQuitListener implements Listener {

    private final EduCraftPlugin plugin;

    public PlayerQuitListener(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Optional<GameSession> sessionOpt = plugin.getSessionManager().getSessionForPlayer(event.getPlayer().getUniqueId());
        sessionOpt.ifPresent(session -> {
            session.removePlayer(event.getPlayer().getUniqueId());
            if (session.getPlayers().isEmpty()) {
                plugin.getCleanupManager().cleanupSession(session);
            }
        });
        plugin.getPlayerManager().removePlayer(event.getPlayer().getUniqueId());
    }
}

