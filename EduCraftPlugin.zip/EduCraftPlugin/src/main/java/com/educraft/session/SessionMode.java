package com.educraft.session;

public enum SessionMode {
    CLASS,
    SOLO
}

