package com.educraft.teleport;

import com.educraft.EduCraftPlugin;
import com.educraft.arena.Arena;
import com.educraft.session.GameSession;
import com.educraft.session.SessionStatus;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class TeleportManager {

    private final EduCraftPlugin plugin;

    public TeleportManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean teleportToArena(Player player, Arena arena, GameSession session) {
        if (player == null || arena == null || session == null) return false;
        if (session.getStatus() == SessionStatus.CLOSED || session.getStatus() == SessionStatus.CLEANING) return false;

        Bukkit.getScheduler().runTask(plugin, () -> player.teleport(arena.getSpawnPoint()));
        return true;
    }

    public void teleportToLobby(Player player) {
        plugin.getLobbyManager().sendToLobby(player);
    }
}

