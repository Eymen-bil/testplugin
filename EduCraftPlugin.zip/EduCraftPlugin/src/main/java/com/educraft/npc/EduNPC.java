package com.educraft.npc;

import org.bukkit.Location;
import org.bukkit.entity.Villager;

public class EduNPC {
    private final String id;
    private final String name;
    private final String locationKey;
    private final String questId;
    private Villager entity;

    public EduNPC(String id, String name, String locationKey, String questId) {
        this.id = id;
        this.name = name;
        this.locationKey = locationKey;
        this.questId = questId;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getLocationKey() { return locationKey; }
    public String getQuestId() { return questId; }
    public Villager getEntity() { return entity; }
    public void setEntity(Villager entity) { this.entity = entity; }
}

