package com.educraft.api;

import com.educraft.EduCraftPlugin;
import com.educraft.security.SessionSecurity;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class EduCraftApiClient {

    private final EduCraftPlugin plugin;
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public EduCraftApiClient(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofMillis(plugin.getConfigManager().getApiTimeoutMs()))
            .build();
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    private HttpRequest.Builder createBaseRequest(String endpoint) {
        String baseUrl = plugin.getConfigManager().getApiBaseUrl();
        String apiKey = plugin.getConfigManager().getApiKey();
        String apiSecret = plugin.getConfigManager().getApiSecret();
        
        long timestamp = System.currentTimeMillis();
        String nonce = SessionSecurity.generateNonce();
        String payloadToSign = apiKey + ":" + timestamp + ":" + nonce;
        String signature = SessionSecurity.computeHmacSha256(payloadToSign, apiSecret);

        return HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + endpoint))
            .header("Content-Type", "application/json")
            .header("X-API-Key", apiKey)
            .header("X-Timestamp", String.valueOf(timestamp))
            .header("X-Nonce", nonce)
            .header("X-Signature", signature)
            .timeout(Duration.ofMillis(plugin.getConfigManager().getApiTimeoutMs()));
    }

    public <T> CompletableFuture<ApiResponse<T>> getAsync(String endpoint, TypeReference<ApiResponse<T>> typeRef) {
        HttpRequest request = createBaseRequest(endpoint).GET().build();
        return sendAsync(request, typeRef);
    }

    public <T> CompletableFuture<ApiResponse<T>> postAsync(String endpoint, Object body, TypeReference<ApiResponse<T>> typeRef) {
        try {
            String jsonBody = objectMapper.writeValueAsString(body);
            HttpRequest request = createBaseRequest(endpoint)
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();
            return sendAsync(request, typeRef);
        } catch (Exception e) {
            return CompletableFuture.completedFuture(ApiResponse.error("JSON serialization failed: " + e.getMessage()));
        }
    }

    private <T> CompletableFuture<ApiResponse<T>> sendAsync(HttpRequest request, TypeReference<ApiResponse<T>> typeRef) {
        return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
            .thenApply(response -> {
                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    try {
                        return objectMapper.readValue(response.body(), typeRef);
                    } catch (Exception e) {
                        return ApiResponse.<T>error("Failed to parse API response: " + e.getMessage());
                    }
                } else {
                    return ApiResponse.<T>error("HTTP " + response.statusCode() + ": " + response.body());
                }
            })
            .exceptionally(ex -> ApiResponse.error("Network error: " + ex.getMessage()));
    }
}

