package com.educraft.quest;

import com.educraft.EduCraftPlugin;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class QuestManager {

    private final EduCraftPlugin plugin;
    private final Map<String, Quest> activeQuests;

    public QuestManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
        this.activeQuests = new ConcurrentHashMap<>();
    }

    public Quest createTestQuest() {
        List<QuestStep> steps = List.of(
            new QuestStep(1, "TALK", "elder_arin", "Elder Arin ile konuş"),
            new QuestStep(2, "ANSWER", "q123", "Matematik sorusunu çöz"),
            new QuestStep(3, "TRAVEL", "gate", "Hedef noktaya ulaş"),
            new QuestStep(4, "PUZZLE", "gate_01", "Bulmacayı tamamla"),
            new QuestStep(5, "BOSS", "algebra_guardian", "Boss'u yen"),
            new QuestStep(6, "COMPLETE", "end", "Görevi tamamla")
        );
        Quest quest = new Quest("lost-seal", "Kayıp Mühür", steps);
        activeQuests.put(quest.getQuestId(), quest);
        return quest;
    }

    public Quest getQuest(String questId) {
        return activeQuests.get(questId);
    }
}

