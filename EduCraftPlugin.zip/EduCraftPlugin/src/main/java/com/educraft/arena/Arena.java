package com.educraft.arena;

import org.bukkit.Location;
import org.bukkit.World;

import java.util.Map;

public class Arena {
    private final String arenaId;
    private final String regionName;
    private final World world;
    private final Location minPoint;
    private final Location maxPoint;
    private final Location spawnPoint;
    private final Map<String, Location> npcLocations;
    private final Location bossLocation;
    private ArenaStatus status;

    public Arena(String arenaId, String regionName, World world, Location minPoint, Location maxPoint,
                 Location spawnPoint, Map<String, Location> npcLocations, Location bossLocation) {
        this.arenaId = arenaId;
        this.regionName = regionName;
        this.world = world;
        this.minPoint = minPoint;
        this.maxPoint = maxPoint;
        this.spawnPoint = spawnPoint;
        this.npcLocations = npcLocations;
        this.bossLocation = bossLocation;
        this.status = ArenaStatus.AVAILABLE;
    }

    public String getArenaId() { return arenaId; }
    public String getRegionName() { return regionName; }
    public World getWorld() { return world; }
    public Location getMinPoint() { return minPoint; }
    public Location getMaxPoint() { return maxPoint; }
    public Location getSpawnPoint() { return spawnPoint; }
    public Map<String, Location> getNpcLocations() { return npcLocations; }
    public Location getBossLocation() { return bossLocation; }
    public ArenaStatus getStatus() { return status; }
    public void setStatus(ArenaStatus status) { this.status = status; }

    public boolean contains(Location loc) {
        if (loc == null || loc.getWorld() == null || !loc.getWorld().equals(world)) return false;
        double x = loc.getX();
        double y = loc.getY();
        double z = loc.getZ();
        return x >= Math.min(minPoint.getX(), maxPoint.getX()) && x <= Math.max(minPoint.getX(), maxPoint.getX()) &&
               y >= Math.min(minPoint.getY(), maxPoint.getY()) && y <= Math.max(minPoint.getY(), maxPoint.getY()) &&
               z >= Math.min(minPoint.getZ(), maxPoint.getZ()) && z <= Math.max(minPoint.getZ(), maxPoint.getZ());
    }
}

