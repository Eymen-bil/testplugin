package com.educraft.quiz;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record Question(
    String questionId,
    String type,
    String question,
    List<String> options
) {}

