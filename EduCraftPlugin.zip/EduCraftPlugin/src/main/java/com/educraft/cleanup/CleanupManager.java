package com.educraft.cleanup;

import com.educraft.EduCraftPlugin;
import com.educraft.arena.Arena;
import com.educraft.session.GameSession;
import com.educraft.session.SessionPlayer;
import com.educraft.session.SessionStatus;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class CleanupManager {

    private final EduCraftPlugin plugin;

    public CleanupManager(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void cleanupSession(GameSession session) {
        session.setStatus(SessionStatus.CLEANING);

        for (SessionPlayer sp : session.getPlayers().values()) {
            Player player = Bukkit.getPlayer(sp.getUuid());
            if (player != null && player.isOnline()) {
                plugin.getLobbyManager().sendToLobby(player);
            }
        }

        plugin.getNpcManager().removeNPCsForSession(session.getSessionId());
        plugin.getBossManager().removeBossForSession(session.getSessionId());

        if (session.getArenaId() != null) {
            plugin.getArenaManager().releaseAndResetArena(session.getArenaId());
        }

        session.setStatus(SessionStatus.CLOSED);
        plugin.getSessionManager().unregisterSession(session.getSessionId());
    }
}

