package com.educraft.session;

public enum SessionStatus {
    WAITING,
    STARTING,
    RUNNING,
    PAUSED,
    CLEANING,
    CLOSED
}

