package com.educraft;

import com.educraft.analytics.AnalyticsManager;
import com.educraft.api.EduCraftApiClient;
import com.educraft.arena.ArenaManager;
import com.educraft.boss.BossManager;
import com.educraft.cleanup.CleanupManager;
import com.educraft.command.EduCraftAdminCommand;
import com.educraft.command.EduCraftCommand;
import com.educraft.config.ConfigManager;
import com.educraft.listener.*;
import com.educraft.lobby.LobbyManager;
import com.educraft.npc.NPCManager;
import com.educraft.player.PlayerManager;
import com.educraft.puzzle.PuzzleManager;
import com.educraft.quest.QuestManager;
import com.educraft.quiz.QuizManager;
import com.educraft.reward.RewardManager;
import com.educraft.session.SessionManager;
import com.educraft.teleport.TeleportManager;

import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class EduCraftPlugin extends JavaPlugin {

    private ConfigManager configManager;
    private EduCraftApiClient apiClient;
    private LobbyManager lobbyManager;
    private ArenaManager arenaManager;
    private SessionManager sessionManager;
    private PlayerManager playerManager;
    private QuizManager quizManager;
    private QuestManager questManager;
    private NPCManager npcManager;
    private PuzzleManager puzzleManager;
    private BossManager bossManager;
    private RewardManager rewardManager;
    private AnalyticsManager analyticsManager;
    private TeleportManager teleportManager;
    private CleanupManager cleanupManager;

    @Override
    public void onEnable() {
        getLogger().info("EduCraftPlugin başlatılıyor (Paper 1.21.8 / Java 21)...");

        this.configManager = new ConfigManager(this);
        this.configManager.loadConfig();

        this.apiClient = new EduCraftApiClient(this);
        this.lobbyManager = new LobbyManager(this);
        this.arenaManager = new ArenaManager(this);
        this.sessionManager = new SessionManager(this);
        this.playerManager = new PlayerManager(this);
        this.quizManager = new QuizManager(this);
        this.questManager = new QuestManager(this);
        this.npcManager = new NPCManager(this);
        this.puzzleManager = new PuzzleManager(this);
        this.bossManager = new BossManager(this);
        this.rewardManager = new RewardManager(this);
        this.analyticsManager = new AnalyticsManager(this);
        this.teleportManager = new TeleportManager(this);
        this.cleanupManager = new CleanupManager(this);

        registerListeners();
        registerCommands();

        sessionManager.syncSessionsFromBackend();

        getLogger().info("EduCraftPlugin başarıyla aktif edildi!");
    }

    @Override
    public void onDisable() {
        getLogger().info("EduCraftPlugin kapatılıyor, aktif sessionlar temizleniyor...");
        if (sessionManager != null) {
            sessionManager.getActiveSessions().values().forEach(session -> cleanupManager.cleanupSession(session));
        }
    }

    private void registerListeners() {
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerJoinListener(this), this);
        pm.registerEvents(new PlayerQuitListener(this), this);
        pm.registerEvents(new PlayerInteractListener(this), this);
        pm.registerEvents(new InventoryListener(this), this);
        pm.registerEvents(new DamageListener(this), this);
        pm.registerEvents(new MovementListener(this), this);
    }

    private void registerCommands() {
        if (getCommand("educraft") != null) {
            getCommand("educraft").setExecutor(new EduCraftCommand(this));
        }
        if (getCommand("educraftadmin") != null) {
            getCommand("educraftadmin").setExecutor(new EduCraftAdminCommand(this));
        }
    }

    public ConfigManager getConfigManager() { return configManager; }
    public EduCraftApiClient getApiClient() { return apiClient; }
    public LobbyManager getLobbyManager() { return lobbyManager; }
    public ArenaManager getArenaManager() { return arenaManager; }
    public SessionManager getSessionManager() { return sessionManager; }
    public PlayerManager getPlayerManager() { return playerManager; }
    public QuizManager getQuizManager() { return quizManager; }
    public QuestManager getQuestManager() { return questManager; }
    public NPCManager getNpcManager() { return npcManager; }
    public PuzzleManager getPuzzleManager() { return puzzleManager; }
    public BossManager getBossManager() { return bossManager; }
    public RewardManager getRewardManager() { return rewardManager; }
    public AnalyticsManager getAnalyticsManager() { return analyticsManager; }
    public TeleportManager getTeleportManager() { return teleportManager; }
    public CleanupManager getCleanupManager() { return cleanupManager; }
}

