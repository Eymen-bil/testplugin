package com.educraft.arena;

import com.educraft.EduCraftPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.concurrent.CompletableFuture;

public class ArenaResetter {

    private final EduCraftPlugin plugin;

    public ArenaResetter(EduCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public CompletableFuture<Boolean> resetArena(Arena arena) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();

        Bukkit.getScheduler().runTask(plugin, () -> {
            try {
                if (arena.getWorld() != null) {
                    for (Entity entity : arena.getWorld().getEntities()) {
                        if (!(entity instanceof Player) && arena.contains(entity.getLocation())) {
                            entity.remove();
                        }
                    }
                }
                
                plugin.getLogger().info("Arena " + arena.getArenaId() + " successfully reset and cleared.");
                future.complete(true);
            } catch (Exception e) {
                plugin.getLogger().severe("Failed to reset arena " + arena.getArenaId() + ": " + e.getMessage());
                future.complete(false);
            }
        });

        return future;
    }
}

