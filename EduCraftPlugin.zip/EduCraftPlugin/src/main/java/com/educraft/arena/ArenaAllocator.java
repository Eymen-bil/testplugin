package com.educraft.arena;

import java.util.Map;
import java.util.Optional;

public class ArenaAllocator {

    private final Map<String, Arena> arenas;

    public ArenaAllocator(Map<String, Arena> arenas) {
        this.arenas = arenas;
    }

    public synchronized Optional<Arena> allocateNextAvailable() {
        return arenas.values().stream()
            .filter(a -> a.getStatus() == ArenaStatus.AVAILABLE)
            .findFirst()
            .map(arena -> {
                arena.setStatus(ArenaStatus.IN_USE);
                return arena;
            });
    }

    public synchronized void releaseArena(String arenaId) {
        Arena arena = arenas.get(arenaId);
        if (arena != null) {
            arena.setStatus(ArenaStatus.CLEANING);
        }
    }
}

